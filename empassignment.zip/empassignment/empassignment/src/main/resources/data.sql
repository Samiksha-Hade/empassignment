insert into employee(id, name, last_name) 
values(100,'Samiksha','Sam');
insert into employee (id, name, last_name) 
values(101,'Ishwari' ,'Ishu' );
insert into employee(id, name, last_name ) 
values(102,'Mrunal', 'Mru');



















